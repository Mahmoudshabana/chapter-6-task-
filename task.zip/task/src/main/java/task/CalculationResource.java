package task;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;

@Path("/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Stateless
public class CalculationResource {
    @PersistenceContext
    EntityManager entityManager;

    @POST
    @Path("/calc")
    public Response createCalculation(Calculation calculation) {
        int result = 0;
        switch (calculation.getOperation()) {
            case "+":
                result = calculation.getNumber1() + calculation.getNumber2();
                break;
            case "-":
                result = calculation.getNumber1() - calculation.getNumber2();
                break;
            case "*":
                result = calculation.getNumber1()* calculation.getNumber2();
                break;
            case "/":
                result = calculation.getNumber1() / calculation.getNumber2();
                break;
            default:
                return Response.status(400).entity("Invalid operation").build();
        }

      //  calculation.setId(0); // set to 0 to ensure new record is inserted
        entityManager.persist(calculation);
        
        return Response.ok().entity("{\"Result\": " + result + "}").build();
    }

    @GET
    @Path("/calculations")
    public Response getAllCalculations() {
        List<Calculation> calculations = entityManager.createQuery("SELECT c FROM Calculation c", Calculation.class)
                .getResultList();

        return Response.ok().entity(calculations).build();
    }
}